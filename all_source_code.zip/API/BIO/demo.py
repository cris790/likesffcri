# استيراد المكتبات المطلوبة
import my_pb2  # استبدل باسم ملف Protobuf الخاص بك
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import requests
import time
import warnings
from datetime import datetime  # 📌 استيراد datetime لإضافة الوقت الحالي

# تجاهل تحذيرات طلبات HTTPS غير الموثقة
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# استيراد مفتاح AES و IV من ملف key_iv.py
from key_iv import AES_KEY, AES_IV

# **رابط API لجلب التوكن**
TOKEN_API = "http://164.92.134.31:50011/token"

# **رابط API لإرسال البيانات**
DATA_API = "https://clientbp.ggblueshark.com/UpdateSocialBasicInfo"

# **الهيدر الأساسي للطلب**
HEADERS_TEMPLATE = {
    'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'Content-Type': "application/octet-stream",
    'Expect': "100-continue",
    'X-Unity-Version': "2018.4.11f1",
    'X-GA': "v1 1",
    'ReleaseVersion': "OB47",
}

# **إنشاء جلسة `requests` لتحسين الأداء**
session = requests.Session()

# **دالة لجلب توكن واحد فقط من API**
def fetch_token():
    try:
        response = session.get(TOKEN_API, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, list) and len(data) > 0 and "token" in data[0]:
                return data[0]["token"]  # **إرجاع التوكن الأول فقط**
    except requests.RequestException as e:
        print(f"❌ فشل جلب التوكن: {e}")
    return None

# **دالة التشفير باستخدام AES**
def encrypt_message(key, iv, plaintext):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_message = pad(plaintext, AES.block_size)
    return cipher.encrypt(padded_message)

# **دالة إرسال البيانات باستخدام التوكن الواحد**
def send_encrypted_data():
    token = fetch_token()  # **جلب التوكن**
    if not token:
        print("⚠️ لم يتم العثور على أي توكن! سيتم إعادة المحاولة بعد 10 ثوانٍ.")
        time.sleep(10)
        return send_encrypted_data()  # **إعادة المحاولة بعد 10 ثوانٍ**

    def send_request(token):
        headers = HEADERS_TEMPLATE.copy()
        headers['Authorization'] = f"Bearer {token}"

        message = my_pb2.Signature()
        message.field2 = 9
        
        # 📌 **إدراج الوقت الحالي داخل `field8`**
        current_time = datetime.now().strftime("%H:%M:%S %d/%m/%Y")
        message.field8 = f"[00FF00][b][c]DEV : @MR3SKR , @X_O_E , @mohp4 [90EE90][b][c]Current time: {current_time}"  # ✅ الوقت الحالي
        
        message.field9 = 1

        encrypted_data = encrypt_message(AES_KEY, AES_IV, message.SerializeToString())

        response = session.post(DATA_API, data=encrypted_data, headers=headers, verify=False)

        try:
            response_text = response.content.decode('utf-8')
        except UnicodeDecodeError:
            response_text = response.content.decode('latin1')

        print(f"✅ [{current_time}] استجابة السيرفر: {response_text}")  # ✅ طباعة الوقت مع الاستجابة

    while True:
        send_request(token)  # **إرسال الطلب مباشرةً**
        time.sleep(0.1)  # **تقليل التأخير بين الطلبات**

# **تشغيل دالة الإرسال**
send_encrypted_data()